empyricaldist
=============

Python library that represents empirical distribution functions.

To see an example, you can `read this
notebook <https://nbviewer.jupyter.org/github/AllenDowney/empiricaldist/blob/master/empiricaldist/dist_demo.ipynb>`__
or `run it on
Binder <https://mybinder.org/v2/gh/AllenDowney/empiricaldist/master?filepath=empiricaldist%2Fdist_demo.ipynb>`__.
